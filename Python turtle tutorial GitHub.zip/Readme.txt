BY MICHAEL DE SANTA OFFICIAL:-
Github:- Michael DeSantaOfficial or TheGrim0114
Discord:- MichaelDeSantaOfficial
If you've learned python turtle and want to understand it more clearly then use my program...