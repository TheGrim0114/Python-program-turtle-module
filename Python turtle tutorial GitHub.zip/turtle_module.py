#First we need to import the module.
#This module is pre-installed in python so don't use pip.
import turtle
turtle.bgcolor('black')
#I've used T as a variable and which means turtle. You can use any word you want to.
t = turtle.Turtle()
colors=['red','dark red']
#I've used for loop here.
#The length of the line is defined by the value stored in the variable number.
for x in range(999999999999):
    t.forward(x+1)
    t.right(89)
    t.pencolor(colors[x%2])
turtle.done()
#Hope you understood😅

